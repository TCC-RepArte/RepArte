<?php
/**
 * Script para adicionar VLibras em todas as páginas principais
 */

// Inclui o arquivo de configuração do VLibras
require_once __DIR__ . '/php/vlibras_config.php';

// Renderiza o VLibras se estiver ativo
renderizarVLibras();
?>